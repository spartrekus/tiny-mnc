 
#include <ncurses.h>
static int compare_fun( const void *p, const void *q){
  const char *l = p ; 
  const char *r = q ; 
  int cmp; 
  cmp = strcmp( l, r );
  return cmp; 
}

int main()
{	

    int ch = 0; 
    int selection = 0; 
    int scrolly = 0; 

    char line[PATH_MAX];
    char cmdi[250];
    char filetarget[250];
    char idata[1240][250];

    char currentselection[PATH_MAX];
    strncpy( currentselection, "", PATH_MAX );

    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;

  void loaddir()
  {
    n = 0 ; 
    filemax = 0; 
    dirp = opendir( "." );
    while  ((dp = readdir( dirp )) != NULL  &&  
            n < sizeof idata / sizeof idata[ 0 ]) {
            if ( strcmp( dp->d_name , "." ) != 0 )
            if ( strcmp( dp->d_name , ".." ) != 0 )
            if ( dp->d_name[0] !=  '.' )
            {
              strncpy( idata[ n++ ] , dp->d_name , 250 );
            }
    }
    filemax = n-1 ; 
    closedir( dirp );

    if ( n > 1 )
      qsort( idata, n , sizeof idata[0], compare_fun );
  }





   initscr();			
   curs_set( 0 );
   int rows, cols;  
   getmaxyx( stdscr, rows, cols);


   void drawit(){
    attroff( A_REVERSE );
    erase();
    int posy=2;
    for( n = 0 ; n <= filemax ; n++)
    {
        if ( n >= scrolly )  
        if ( posy <= rows-3 )  
        {
          if ( selection == n ) mvprintw( posy , 0, ">" );
          if ( selection == n ) attron(  A_REVERSE );
          if ( selection == n )
             strncpy( currentselection, idata[ n ] , PATH_MAX );
          if ( fexist( idata[ n ] ) == 2 )
            mvprintw( posy , 1, "[%s]", idata[ n ] );
          else
            mvprintw( posy , 1, "%s", idata[ n ] );
          posy++;
          attroff(  A_REVERSE );
        }
    }
   }




  void mncview( char *thefile )
  {
    int posy=2;
    FILE *fp;
    posy = 1 ; 
    int mncview_gameover = 0;
    int mncview_scrolly = 0;
    while( mncview_gameover == 0 )
    {
      if ( mncview_scrolly <= 0 ) mncview_scrolly = 0;
      attroff( A_REVERSE );
      erase();
      posy = 0; 
      fp = fopen( thefile  , "rb" ) ; 
      while ( ( posy <= rows -2 ) && (!feof(fp)) ) 
      { 
        fgets(line , PATH_MAX , fp ); 
  	if ( !feof( fp ) )
  	{
  	   mvprintw( posy - mncview_scrolly , 0, "%s", strrlf( line ));
  	   posy++;
  	}
      }
      fclose( fp );
      attron( A_REVERSE );
      for ( n = 0; n <= cols-1; n++) mvaddch( rows-1, n , ' ' );
      mvprintw( rows-1, 0, "|%d|[%s]", mncview_scrolly, thefile);

      ch = getch();
      switch( ch ){
         case 'r':
         case 'i':
          mncview_gameover = 1;
	  break;
	 case 'd':
	 case 'n':
	  mncview_scrolly += 4; 
	  break;
	 case 'u':
	  mncview_scrolly -= 4; 
	  break;
	 case 'j':
	  mncview_scrolly++;
	  break;
	 case 'k':
	  mncview_scrolly--;
	  break;
	 case 'g':
          mncview_scrolly = 0;
	  break;
      }
    }
    attroff( A_REVERSE );
  }


    

    void refinitdir()
    {
                  selection = 0;
                  scrolly = 0;
		  loaddir();
    }



       int mnc_gameover = 0;
       while( mnc_gameover == 0 )
       {
        if ( scrolly <= 0 )   scrolly = 0; 
        if ( selection <= 0 ) selection = 0; 
        loaddir();
        drawit();

        attron( A_REVERSE );
	for ( n = 0; n <= cols-1; n++) mvaddch( rows-1, n , ' ' );
	for ( n = 0; n <= cols-1; n++) mvaddch( 0 , n , ' ' );
        mvprintw( 0 , cols-10, "[MNC](L)");
        mvprintw(rows-1 , 0, "[hjkl: move][q:quit mnc]");
        attroff( A_REVERSE );

        refresh();
        ch = getch();

         switch( ch )
 	 {
               case 'q':
	          mnc_gameover = 1;
                  break;
               case 'd':
               case 'n':
                  scrolly +=4;
                  selection +=4;
                  break;
               case 'u':
                  scrolly -=4;
                  selection -=4;
                  break;
               case 'k':
                  selection--;
                  break;
               case 'j':
                  selection++;
                  break;
               case 'g':
	          mvprintw( rows-1, cols-3 , "[g]" );
		  refresh();
	          ch = getch(); 
	          if ( ch == 'g' ) 
		  {
		     refinitdir();
		  }
                  break;

               case 'O':
                  break;

               case 'o':
	          mvprintw( rows-1, cols-3 , "[o]" );
		  refresh();
	          ch = getch(); 
	          if ( ch == 32 ) 
		  {
                    chdir( getenv( "HOME" ) );
		    refinitdir();
		  }
                  break;

               case '/':
	          chdir( "/" );
		  refinitdir();
                  break;
               case '~':
	          chdir( getenv( "HOME" ) );
		  refinitdir();
                  break;

               case 'h':
	          chdir( ".." );
		  refinitdir();
                  break;
               case 'l':
	          if ( strcmp( currentselection, "" ) != 0 )
		  {
	            chdir( currentselection );
                    selection = 1;
                    scrolly = 0;
		  }
                  break;

               case 'L':
                  getmaxyx( stdscr, rows, cols);
                  break;

               case 'r':
	          if ( strcmp( currentselection, "" ) != 0 )
		  if ( fexist( currentselection ) == 1 )
		  {
	             mncview( currentselection );
		     loaddir();
		  }
                  break;

        }
       }

       curs_set( 1 );
       endwin();	 
       return 0;
}





